'use client'

import { cn } from '@/lib/utils'
import { useCategories } from '@/hooks/useCategories'

interface CategoryQuickNavProps {
  activeCategory: string
  onSelect: (slug: string) => void
}

// SVG-іконки для відомих категорій
const categoryIcons: Record<string, React.ReactNode> = {
  default: (
    <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
      <path d="M20 6 L8 18 L8 34 L32 34 L32 18 Z" />
      <path d="M15 34 L15 24 L25 24 L25 34" />
    </svg>
  ),
}

// Унікальні іконки для кожної категорії по ключовому слову
function getCategoryIcon(slug: string, label: string): React.ReactNode {
  const s = (slug + label).toLowerCase()

  // 3D-моделі
  if (s.includes('3d') || s.includes('модел'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M20 4 L36 13 L36 27 L20 36 L4 27 L4 13 Z" />
        <path d="M20 4 L20 36M4 13 L36 13M4 27 L36 27" />
      </svg>
    )

  // Мармур
  if (s.includes('мармур'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <rect x="8" y="6" width="24" height="28" rx="1" />
        <path d="M12 14 Q18 10 24 16 Q30 22 34 18" />
        <path d="M8 24 Q14 20 20 24 Q26 28 32 24" />
      </svg>
    )

  // Меморіальні комплекси / сімейні
  if (s.includes('комплекс') || s.includes('сімейн'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M10 10 L10 34 L18 34 L18 10 Z" />
        <path d="M22 16 L22 34 L30 34 L30 16 Z" />
        <path d="M14 10 Q14 6 14 6" strokeLinecap="round" />
        <path d="M8 10 L20 10M20 16 L32 16" />
      </svg>
    )

  // Елітні / ексклюзивні
  if (s.includes('еліт') || s.includes('ексклюзив'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M20 4 L23 14 L34 14 L25 21 L28 32 L20 26 L12 32 L15 21 L6 14 L17 14 Z" />
      </svg>
    )

  // Військові / ЗСУ
  if (s.includes('військ') || s.includes('зсу'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M20 4 L32 10 L32 22 C32 29 26 35 20 37 C14 35 8 29 8 22 L8 10 Z" />
        <path d="M14 20 L18 24 L26 16" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    )

  // Різьблені
  if (s.includes('різьбл'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M12 6 L28 6 L28 34 L12 34 Z" />
        <path d="M16 12 Q20 10 24 12" />
        <path d="M15 17 Q20 15 25 17" />
        <path d="M16 22 L24 22M17 26 L23 26" />
      </svg>
    )

  // Європейський стиль
  if (s.includes('європ'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M14 6 Q14 4 20 4 Q26 4 26 6 L26 34 L14 34 Z" />
        <path d="M14 14 L26 14M14 22 L26 22" />
        <ellipse cx="20" cy="10" rx="3" ry="2" />
      </svg>
    )

  // Одинарні
  if (s.includes('одинарн') || s.includes('forone') || s.includes('на одного'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M16 6 Q16 4 20 4 Q24 4 24 6 L24 34 L16 34 Z" />
        <path d="M14 34 L26 34" strokeLinecap="round" />
      </svg>
    )

  // Подвійні
  if (s.includes('подвійн'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M10 10 Q10 7 14 7 Q18 7 18 10 L18 34 L10 34 Z" />
        <path d="M22 14 Q22 11 26 11 Q30 11 30 14 L30 34 L22 34 Z" />
        <path d="M8 34 L32 34" strokeLinecap="round" />
      </svg>
    )

  // Горизонтальні
  if (s.includes('горизонт'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <rect x="6" y="16" width="28" height="14" rx="1" />
        <path d="M12 16 L12 10 L28 10 L28 16" />
        <path d="M6 30 L34 30" />
      </svg>
    )

  // Для жінок
  if (s.includes('жінок') || s.includes('жіноч'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <circle cx="20" cy="14" r="6" />
        <path d="M20 20 L20 30M16 26 L24 26" strokeLinecap="round" />
        <path d="M14 34 L26 34M16 34 L16 30 L24 30 L24 34" />
      </svg>
    )

  // Для чоловіків
  if (s.includes('чолов'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M14 8 L26 8 L28 20 L20 24 L12 20 Z" />
        <path d="M16 24 L14 34 L20 30 L26 34 L24 24" />
        <path d="M14 34 L26 34" strokeLinecap="round" />
      </svg>
    )

  // Дитячі
  if (s.includes('дитяч') || s.includes('children'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M17 6 Q17 4 20 4 Q23 4 23 6 L23 34 L17 34 Z" />
        <path d="M15 34 L25 34" strokeLinecap="round" />
        <circle cx="20" cy="10" r="2" />
        <path d="M16 18 Q20 16 24 18" />
      </svg>
    )

  // Лебеді
  if (s.includes('лебед'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M8 24 Q12 16 18 14 Q24 12 28 16 Q32 20 30 24" />
        <path d="M8 24 Q10 28 16 28 Q22 28 26 24 Q30 20 30 24" />
        <path d="M14 34 L26 34" strokeLinecap="round" />
        <path d="M16 28 L16 34M24 28 L24 34" />
      </svg>
    )

  // Серце
  if (s.includes('серц'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M20 32 C20 32 6 22 6 14 C6 10 9 7 13 7 C16 7 18 9 20 11 C22 9 24 7 27 7 C31 7 34 10 34 14 C34 22 20 32 20 32 Z" />
      </svg>
    )

  // Хрест
  if (s.includes('хрест') || s.includes('cross'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M18 6 L22 6 L22 16 L32 16 L32 20 L22 20 L22 34 L18 34 L18 20 L8 20 L8 16 L18 16 Z" />
      </svg>
    )

  // Янголи
  if (s.includes('янгол') || s.includes('angel'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <circle cx="20" cy="8" r="4" />
        <path d="M14 14 Q8 12 6 18 Q10 20 14 18" />
        <path d="M26 14 Q32 12 34 18 Q30 20 26 18" />
        <path d="M14 18 L16 34 L20 28 L24 34 L26 18" />
        <path d="M14 18 Q20 22 26 18" />
      </svg>
    )

  // Скорботна фігура
  if (s.includes('скорботн') || s.includes('фігур'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <circle cx="20" cy="8" r="4" />
        <path d="M14 16 Q12 20 12 26 L14 34 L20 30 L26 34 L28 26 Q28 20 26 16 Q20 18 14 16 Z" />
        <path d="M16 20 Q20 22 24 20" />
      </svg>
    )

  // Бюджетні / недорогі
  if (s.includes('бюджет') || s.includes('недорог'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M17 6 Q17 4 20 4 Q23 4 23 6 L23 34 L17 34 Z" />
        <path d="M15 34 L25 34" strokeLinecap="round" />
        <circle cx="20" cy="16" r="3" />
        <path d="M17 22 L23 22" />
      </svg>
    )

  // Комбіновані / mixed
  if (s.includes('комбін') || s.includes('mixed'))
    return (
      <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
        <path d="M10 12 Q10 8 14 8 Q18 8 18 12 L18 34 L10 34 Z" />
        <path d="M22 18 Q22 14 26 14 Q30 14 30 18 L30 34 L22 34 Z" />
        <path d="M8 34 L32 34" strokeLinecap="round" />
      </svg>
    )

  // За замовчуванням — простий пам'ятник
  return (
    <svg viewBox="0 0 40 40" fill="none" className="w-8 h-8" stroke="currentColor" strokeWidth="1.2">
      <path d="M15 6 Q15 4 20 4 Q25 4 25 6 L25 34 L15 34 Z" />
      <path d="M13 34 L27 34" strokeLinecap="round" />
      <path d="M17 14 L23 14M17 19 L23 19" strokeLinecap="round" />
    </svg>
  )
}

export function CategoryQuickNav({ activeCategory, onSelect }: CategoryQuickNavProps) {
  const { categories, isLoading } = useCategories()

  if (isLoading) {
    return (
      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2 mb-8">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="flex flex-col items-center gap-2 p-2 animate-pulse">
            <div className="w-14 h-14 bg-white/5 rounded-sm" />
            <div className="w-12 h-2 bg-white/5 rounded" />
          </div>
        ))}
      </div>
    )
  }

  const allItem = { id: 'all', slug: 'all', label: 'Всі товари', sort_order: 0, created_at: '' }
  const items = [allItem, ...categories]

  return (
    <div className="mb-8">
      {/* Заголовок блоку */}
      <p className="font-body text-[10px] tracking-[0.4em] uppercase text-mist/40 mb-3">
        Швидка навігація
      </p>

      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 xl:grid-cols-12 gap-1.5">
        {items.map(cat => {
          const isActive = activeCategory === cat.slug
          return (
            <button
              key={cat.id}
              onClick={() => onSelect(cat.slug)}
              title={cat.label}
              className={cn(
                'group flex flex-col items-center gap-1.5 px-1 py-3',
                'transition-all duration-200 border',
                isActive
                  ? 'bg-bordeaux/20 border-bordeaux/50 text-gold'
                  : 'bg-graphite/60 border-white/[0.06] text-mist/50 hover:bg-graphite hover:border-gold/20 hover:text-gold/80 hover:scale-[1.04]'
              )}
            >
              {/* Іконка */}
              <div className={cn(
                'transition-all duration-200',
                isActive ? 'text-gold' : 'text-mist/40 group-hover:text-gold/70'
              )}>
                {getCategoryIcon(cat.slug, cat.label)}
              </div>

              {/* Назва */}
              <span className={cn(
                'font-body text-[9px] leading-tight text-center tracking-wide line-clamp-2',
                'max-w-[64px] transition-colors duration-200',
                isActive ? 'text-gold' : 'text-mist/40 group-hover:text-mist/80'
              )}>
                {cat.label}
              </span>

              {/* Активний індикатор */}
              {isActive && (
                <span className="w-3 h-px bg-gold/70" />
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
